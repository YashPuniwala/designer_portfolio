export default function HeroSection() {
  return (
    <section
      className="hero-section relative h-full w-full overflow-hidden"
      id="home"
      aria-label="Hero"
    >
      <img
        src="/images/hero.jpg"
        alt="Abstract sculptural monolith with a ribbon of warm light"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/10 to-black/80" />

      <div className="relative z-10 flex h-full flex-col justify-between px-6 pb-8 pt-20 md:px-12 md:pb-10">
        {/* Top meta row */}
        <div className="flex items-start justify-between font-mono text-[10px] uppercase tracking-[0.35em] text-white/50">
          <p>Creative Agency — Est. 2019</p>
          <p className="hidden md:block">Berlin / New York / Tokyo</p>
          <p className="hidden lg:block">Scroll-Driven Cinema</p>
        </div>

        {/* Bottom block */}
        <div>
          <h1 className="font-display text-[16.5vw] font-bold uppercase leading-[0.82] tracking-[-0.02em] text-white md:text-[15vw]">
            Operator
            <span className="text-amber-glow">.X</span>
          </h1>

          <div className="mt-6 flex flex-col gap-5 border-t border-white/15 pt-5 md:mt-8 md:flex-row md:items-end md:justify-between">
            <p className="max-w-md text-sm leading-relaxed text-white/60 md:text-base">
              We engineer bold brand identities and cinematic digital
              experiences that make ambitious work impossible to ignore.
            </p>

            <div className="flex items-center gap-4">
              <span className="font-mono text-[10px] uppercase tracking-[0.35em] text-white/50">
                Scroll to enter
              </span>
              <span className="relative block h-10 w-px overflow-hidden bg-white/20">
                <span className="scroll-line absolute inset-0 bg-white" />
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
