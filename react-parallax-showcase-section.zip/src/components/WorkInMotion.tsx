import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useLayoutEffect, useRef } from "react";

gsap.registerPlugin(ScrollTrigger);

/**
 * The virtual camera's distance from the scene plane. Everything in the
 * grid lives on one flat plane at Z=0 inside a perspective container, so
 * pushing that plane toward the camera (translateZ) produces true
 * projective magnification: the centre card, sitting exactly on the
 * camera axis, stays pinned to the viewport centre while every other card
 * accelerates outward and off-screen — the way a real dolly-in behaves.
 */
const CAMERA_PERSPECTIVE = 1000;

export default function WorkInMotion() {
  const sectionRef = useRef<HTMLElement>(null);
  const worldRef = useRef<HTMLDivElement>(null);
  const centerCardRef = useRef<HTMLDivElement>(null);
  const centerTextRef = useRef<HTMLDivElement>(null);
  const surroundingRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const world = worldRef.current;
    const centerCard = centerCardRef.current;
    const centerText = centerTextRef.current;
    const surrounding = surroundingRef.current;

    if (!section || !world || !centerCard || !centerText) return;

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // How far the scene plane must travel toward the camera for the centre
    // card to fill the viewport. With CSS perspective P, an element at
    // translateZ(z) is magnified by P / (P - z). We solve for the z that
    // yields the required magnification, then push slightly past it so the
    // card bleeds the frame edges (matches the previous *1.05 overshoot).
    const calculateDollyZ = () => {
      const cardRect = centerCard.getBoundingClientRect();
      if (!cardRect.width || !cardRect.height) return CAMERA_PERSPECTIVE * 0.72;
      const needed =
        Math.max(
          window.innerWidth / cardRect.width,
          window.innerHeight / cardRect.height
        ) * 1.05;
      // magnification m = P / (P - z)  =>  z = P * (1 - 1/m)
      return CAMERA_PERSPECTIVE * (1 - 1 / needed);
    };

    if (reduceMotion) {
      // In reduced motion, keep the static composition without the dolly
      return;
    }

    const ctx = gsap.context(() => {
      // ---------------------------------------------------------------
      // SCROLL MODEL
      //
      // • start: "top top" + pin — the section is 100vh, so the pin only
      //   engages once the section is FULLY inside the viewport. Nothing
      //   animates while it is entering; the first scroll AFTER it is
      //   fully visible is what begins the sequence.
      //
      // • scrub: true — a strict 1:1 mapping between scroll position and
      //   timeline progress. The instant the user stops scrolling, the
      //   animation freezes at its exact current progress. No catch-up
      //   momentum, no time-based completion, no autoplay.
      //
      // • end: "+=600%" — six viewports of scroll for the sequence, and
      //   every part of that range maps to visible animation. The old
      //   timeline wasted 25% of the pin on empty holds (0–0.15 dead
      //   intro, 0.90–1.00 dead tail); those are removed, so 100% of the
      //   scroll distance now drives real progress.
      // ---------------------------------------------------------------
      const tl = gsap.timeline({
        scrollTrigger: {
          id: "work-in-motion-zoom",
          trigger: section,
          start: "top top",
          end: "+=600%",
          pin: true,
          scrub: true,
          anticipatePin: 1,
          invalidateOnRefresh: true,
        },
      });

      // -------------------------------------------------------------
      // 0.00 → 0.08 — VISION rises in over the centre image.
      // Begins on the very first scroll after the pin engages.
      // -------------------------------------------------------------
      tl.fromTo(
        centerText,
        { opacity: 0, y: 26, scale: 0.94 },
        { opacity: 1, y: 0, scale: 1, duration: 0.08, ease: "power2.out" },
        0
      );

      // -------------------------------------------------------------
      // 0.06 → 1.00 — CAMERA DOLLY-IN (the spine of the sequence).
      // The scene plane travels toward the camera continuously across
      // ~94% of the pin, so the zoom is slow, precise and always moving
      // with the scroll. power2.in keeps the early travel gentle (VISION
      // stays readable over a calm grid) and accelerates the approach in
      // the final stretch, like physically closing in on the image.
      // -------------------------------------------------------------
      tl.fromTo(
        world,
        { z: 0 },
        {
          z: () => calculateDollyZ(),
          duration: 0.94,
          ease: "power2.in",
        },
        0.06
      );

      // -------------------------------------------------------------
      // 0.72 → 0.88 — surrounding cards, already being carried off the
      // frame edges by the dolly, get a gentle fade so no thin borders
      // linger as they exit. (No individual movement — dolly only.)
      // -------------------------------------------------------------
      if (surrounding) {
        tl.to(
          surrounding,
          { opacity: 0, duration: 0.16, ease: "power1.in" },
          0.72
        );
      }

      // -------------------------------------------------------------
      // 0.80 → 0.90 — VISION leaves. It stays centred and fully visible
      // through the first ~80% of the sequence, then fades out on scroll
      // while the final 20% of the zoom completes underneath it.
      // -------------------------------------------------------------
      tl.to(
        centerText,
        { opacity: 0, y: -20, scale: 1.05, duration: 0.1, ease: "power2.in" },
        0.8
      );

      // -------------------------------------------------------------
      // 0.86 → 0.98 — the centre card's corners square off as it reaches
      // full-bleed, finishing exactly as the pin releases into normal
      // page scroll. No hold, no dead tail.
      // -------------------------------------------------------------
      tl.to(
        centerCard,
        { borderRadius: "0px", duration: 0.12, ease: "power1.inOut" },
        0.86
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="projects"
      className="work-in-motion-section relative h-screen w-full overflow-hidden bg-black text-white select-none"
      aria-label="Work in Motion"
    >
      {/* 100vw x 100vh Full-bleed Stage container */}
      <div className="relative h-full w-full bg-black overflow-hidden">

        {/* ========================================================= */}
        {/* CAMERA — perspective viewport. Its vanishing point is the  */}
        {/* exact centre of the screen, which is also where the centre */}
        {/* card sits, so dollying forward keeps that card locked in   */}
        {/* place while everything else recedes off the edges.         */}
        {/* ========================================================= */}
        <div
          className="absolute inset-0"
          style={{
            perspective: `${CAMERA_PERSPECTIVE}px`,
            perspectiveOrigin: "50% 50%",
          }}
        >
          {/* WORLD — the flat scene plane. Surrounding grid and centre
              card both live here so they magnify together as ONE rigid
              body when the plane travels toward the camera. */}
          <div
            ref={worldRef}
            className="absolute inset-0 p-2 sm:p-2.5 md:p-3"
            style={{
              transformStyle: "preserve-3d",
              transformOrigin: "50% 50%",
              willChange: "transform",
              backfaceVisibility: "hidden",
            }}
          >
        
        {/* ========================================================= */}
        {/* SURROUNDING IMAGES LAYER (Static, zero parallax, no float)  */}
        {/* Exact 2 - 3 - 2 editorial layout matching reference image  */}
        {/* ========================================================= */}
        <div
          ref={surroundingRef}
          className="absolute inset-0 p-2 sm:p-2.5 md:p-3 flex flex-col justify-between pointer-events-none z-10"
          style={{ transformStyle: "preserve-3d" }}
        >
          {/* ROW 1: TOP ROW (2 images, 50% / 50% split) */}
          <div className="grid grid-cols-2 gap-2 sm:gap-2.5 md:gap-3 h-[32%] w-full">
            {/* Top Left: Basketball under harsh spotlight */}
            <div className="relative h-full w-full overflow-hidden rounded-xl sm:rounded-2xl bg-neutral-900 pointer-events-auto">
              <img
                src="/images/motion-basketball.jpg"
                alt="Basketball under dramatic spotlight"
                className="h-full w-full object-cover"
              />
              {/* Reference top pill status badge */}
              <div className="absolute top-3 left-3 hidden sm:flex items-center justify-center h-6 w-7 rounded-md border border-white/20 bg-black/40 backdrop-blur-md">
                <span className="h-2 w-2 rounded-sm border border-white/60" />
              </div>
            </div>

            {/* Top Right: Hands holding translucent amber vial */}
            <div className="relative h-full w-full overflow-hidden rounded-xl sm:rounded-2xl bg-neutral-900 pointer-events-auto">
              <img
                src="/images/motion-amber-hand.jpg"
                alt="Hands holding amber glass vial"
                className="h-full w-full object-cover"
              />
              {/* Reference orange curved accent line */}
              <svg
                className="absolute bottom-2 left-6 w-28 sm:w-44 h-16 pointer-events-none text-[#ff8a3c] opacity-85"
                viewBox="0 0 160 60"
                fill="none"
              >
                <path
                  d="M10 10 Q 80 50, 150 55"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />
              </svg>
            </div>
          </div>

          {/* ROW 2: SIDES OF MIDDLE ROW (Left & Right flanking images) */}
          <div className="grid grid-cols-12 gap-2 sm:gap-2.5 md:gap-3 h-[34%] w-full">
            {/* Mid Left: Red-haired woman with earrings */}
            <div className="col-span-4 h-full w-full overflow-hidden rounded-xl sm:rounded-2xl bg-neutral-900 pointer-events-auto">
              <img
                src="/images/motion-redhead.jpg"
                alt="Editorial portrait of red-haired woman"
                className="h-full w-full object-cover"
              />
            </div>

            {/* Spacer for center zoom tile */}
            <div className="col-span-4 h-full w-full pointer-events-none" />

            {/* Mid Right: Model in beige streetwear hoodie */}
            <div className="col-span-4 h-full w-full overflow-hidden rounded-xl sm:rounded-2xl bg-neutral-900 pointer-events-auto">
              <img
                src="https://images.pexels.com/photos/10210027/pexels-photo-10210027.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
                alt="Editorial streetwear hoodie"
                className="h-full w-full object-cover"
              />
            </div>
          </div>

          {/* ROW 3: BOTTOM ROW (2 images, 50% / 50% split) */}
          <div className="grid grid-cols-2 gap-2 sm:gap-2.5 md:gap-3 h-[32%] w-full">
            {/* Bottom Left: High collar coat and dark sunglasses portrait */}
            <div className="relative h-full w-full overflow-hidden rounded-xl sm:rounded-2xl bg-neutral-900 pointer-events-auto">
              <img
                src="https://images.pexels.com/photos/8718335/pexels-photo-8718335.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
                alt="Model in dark high collar coat and sunglasses"
                className="h-full w-full object-cover"
              />
            </div>

            {/* Bottom Right: Striking silhouette portrait in warm amber light */}
            <div className="relative h-full w-full overflow-hidden rounded-xl sm:rounded-2xl bg-neutral-900 pointer-events-auto">
              <img
                src="https://images.pexels.com/photos/18739891/pexels-photo-18739891.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
                alt="Portrait in vivid warm orange light"
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* ========================================================= */}
        {/* CENTER FOCAL TILE (Dedicated zoom layer, z-index 40)       */}
        {/* Exact width & height matching Row 2, Center Column        */}
        {/* ========================================================= */}
        <div
          className="absolute inset-0 p-2 sm:p-2.5 md:p-3 flex items-center justify-center pointer-events-none z-40"
          style={{ transformStyle: "preserve-3d" }}
        >
          <div
            ref={centerCardRef}
            className="relative h-[34%] w-[calc((100%-1rem)/3)] sm:w-[calc((100%-1.25rem)/3)] md:w-[calc((100%-1.5rem)/3)] overflow-hidden rounded-xl sm:rounded-2xl shadow-2xl bg-neutral-900 pointer-events-auto"
          >
            {/* Center Focal Image: Man in orange bucket hat looking through amber lens */}
            <img
              src="/images/motion-center.jpg"
              alt="Editorial portrait of man looking through amber lens"
              className="h-full w-full object-cover"
            />

            {/* Vignette */}
            <div className="absolute inset-0 bg-radial-[ellipse_at_center] from-transparent via-black/10 to-black/30 pointer-events-none" />
          </div>
        </div>

          </div>
          {/* /WORLD */}
        </div>
        {/* /CAMERA */}

        {/* ========================================================= */}
        {/* CENTER TEXT ANIMATION LAYER (Step 2 in the sequence)      */}
        {/* Lives OUTSIDE the camera so it stays flat and readable.   */}
        {/* ========================================================= */}
        <div
          ref={centerTextRef}
          className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none z-50 px-4 text-center opacity-0"
        >
          <div className="px-2">
            <span className="font-display text-3xl sm:text-5xl md:text-6xl font-bold uppercase tracking-tight text-white block">
              Vision
            </span>
          </div>
        </div>

        {/* Reference Top Status Indicators */}
        <div className="absolute top-4 inset-x-4 flex items-center justify-between pointer-events-none z-30">
          <div className="flex items-center gap-2">
            <div className="h-7 px-3 rounded-full border border-white/20 bg-black/40 backdrop-blur-md hidden sm:flex items-center text-[10px] font-mono text-white/70 uppercase tracking-widest">
              Grid View
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-7 px-3 rounded-full border border-white/20 bg-black/40 backdrop-blur-md flex items-center gap-2 text-[10px] font-mono text-white/70 uppercase">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#ff8a3c] animate-pulse" />
              <span>38%</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
