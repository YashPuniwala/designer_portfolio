import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useLayoutEffect, useRef } from "react";

gsap.registerPlugin(ScrollTrigger);

export default function StatementSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const frame = frameRef.current;
    const inner = innerRef.current;
    if (!section || !frame || !inner) return;

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const img = inner.querySelector<HTMLImageElement>("img");

    const REST_SHADOW = "0 25px 60px rgba(0, 0, 0, 0)";
    const OPEN_SHADOW = "0 25px 60px rgba(0, 0, 0, 0.7)";

    const mm = gsap.matchMedia();

    // -----------------------------------------------------------------
    // DESKTOP & TABLET (> 640px) — 100% UNCHANGED
    // -----------------------------------------------------------------
    mm.add("(min-width: 641px)", () => {
      const getTargetWidth = () => {
        const h = frame.offsetHeight || 80;
        return Math.round(h * 2.55);
      };

      const setTargetDimensions = () => {
        const targetW = getTargetWidth();
        inner.style.width = `${targetW}px`;
        inner.style.minWidth = `${targetW}px`;
        inner.style.height = "100%";
        return targetW;
      };

      if (reduceMotion) {
        const targetW = setTargetDimensions();
        frame.style.width = `${targetW}px`;
        frame.style.height = "0.82em";
        frame.style.margin = "0 0.26em";
        frame.style.boxShadow = OPEN_SHADOW;
        return;
      }

      setTargetDimensions();
      gsap.set(frame, {
        width: 0,
        height: "0.82em",
        margin: "0 0.1em",
        boxShadow: REST_SHADOW,
      });
      if (img) gsap.set(img, { scale: 1 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: "+=120%",
          pin: true,
          scrub: 0.8,
          anticipatePin: 1,
          invalidateOnRefresh: true,
          onRefresh: () => {
            setTargetDimensions();
          },
        },
      });

      // 1. Initial stationary phase:
      // The section is pinned in full view; user clearly sees "NOBODY REMEMBERS / POLITE DESIGN."
      tl.to({}, { duration: 0.18 });

      // 2. Horizontal expansion from left -> right:
      // Width animates 0 -> target width while the image inside remains fixed.
      tl.fromTo(
        frame,
        { width: 0, margin: "0 0.1em", boxShadow: REST_SHADOW },
        {
          width: () => getTargetWidth(),
          margin: "0 0.26em",
          boxShadow: OPEN_SHADOW,
          duration: 0.67,
          ease: "none",
        }
      );

      // 3. Final hold:
      // Stays at its full final width before unpinning cleanly into the next section.
      tl.to({}, { duration: 0.15 });
    });

    // -----------------------------------------------------------------
    // MOBILE (<= 640px)
    // Initial: 4 clean stacked lines with natural typography spacing:
    //   NOBODY
    //   REMEMBERS
    //   POLITE
    //   DESIGN.
    // On scroll: space opens dynamically, image reveals and expands,
    // zoom effect continues, then unpins cleanly into next section.
    // -----------------------------------------------------------------
    mm.add("(max-width: 640px)", () => {
      // Keep the image as a small embedded element between POLITE and DESIGN.
      // The image is capped well below the viewport width on every phone
      // size (430 / 390 / 375 / 360 / 320) and at a compact height so it
      // never becomes a large banner. The 2.4:1 image stays close to its
      // natural ratio (rounded card 220x92 by default, scaling to 124x52
      // on the smallest 320px screens) so POLITE and DESIGN. stay close.
      const IMAGE_RATIO = 2.4;
      const getTargetHeight = () => {
        // Compact height: 64px on tiny screens, up to 96px on larger phones.
        return Math.max(56, Math.min(96, Math.round(window.innerWidth * 0.21)));
      };

      const getTargetWidth = () => {
        const h = getTargetHeight();
        // Width is locked to the image's natural aspect ratio, capped
        // generously well under the viewport so the row stays compact.
        return Math.max(80, Math.min(220, Math.round(h * IMAGE_RATIO)));
      };

      const setMobileDimensions = () => {
        const targetW = getTargetWidth();
        const targetH = getTargetHeight();
        inner.style.width = "100%";
        inner.style.minWidth = "0px";
        inner.style.height = `${targetH}px`;
        return { targetW, targetH };
      };

      if (reduceMotion) {
        const { targetW, targetH } = setMobileDimensions();
        frame.style.width = `${targetW}px`;
        frame.style.height = `${targetH}px`;
        frame.style.margin = "0.35em 0";
        frame.style.boxShadow = OPEN_SHADOW;
        return;
      }

      setMobileDimensions();
      // Initial state: height: 0, width: 0, margin: 0 — ZERO reserved space!
      gsap.set(frame, {
        height: 0,
        width: 0,
        margin: "0px 0px",
        boxShadow: REST_SHADOW,
      });
      if (img) gsap.set(img, { scale: 1.15 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: "+=150%",
          pin: true,
          scrub: 0.8,
          anticipatePin: 1,
          invalidateOnRefresh: true,
          onRefresh: () => {
            setMobileDimensions();
          },
        },
      });

      // 1. Initial hold: User sees clean stacked words:
      //    NOBODY / REMEMBERS / POLITE / DESIGN.
      tl.to({}, { duration: 0.15 });

      // 2. Space opens dynamically between POLITE and DESIGN. as height & margin expand,
      //    while width expands to reveal the image horizontally.
      tl.fromTo(
        frame,
        {
          height: 0,
          width: 0,
          margin: "0px 0px",
          boxShadow: REST_SHADOW,
        },
        {
          height: () => getTargetHeight(),
          width: () => getTargetWidth(),
          margin: "0.35em 0",
          boxShadow: OPEN_SHADOW,
          duration: 0.65,
          ease: "none",
        }
      );

      // 3. Tiny zoom into the image as it opens (stays compact on mobile)
      if (img) {
        tl.fromTo(
          img,
          { scale: 1.1 },
          { scale: 1.0, duration: 0.65, ease: "none" },
          "<"
        );
      }

      // 4. Final hold before cleanly continuing to next section
      tl.to({}, { duration: 0.2 });
    });

    return () => mm.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="statement"
      className="statement-section"
      aria-label="Design statement"
    >
      <div className="statement-inner">
        <div className="statement-row statement-row-1">
          NOBODY
          <br className="statement-break" />
          REMEMBERS
        </div>
        <div className="statement-row statement-row-2">
          <span className="statement-word statement-word-polite">POLITE</span>
          <div ref={frameRef} className="statement-image-frame">
            <div ref={innerRef} className="statement-image-inner">
              <img
                src="/about-section-image.png"
                alt="Featured work"
              />
            </div>
          </div>
          <span className="statement-word">DESIGN.</span>
        </div>
      </div>
    </section>
  );
}
