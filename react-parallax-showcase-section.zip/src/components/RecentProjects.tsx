import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useLayoutEffect, useRef } from "react";

gsap.registerPlugin(ScrollTrigger);

type Project = {
  id: string;
  slug: string;
  title: string;
  category: string;
  src: string;
  ratio: "rp-ratio-4-3" | "rp-ratio-3-4" | "rp-ratio-16-9" | "rp-ratio-square";
  /* starting horizontal compression — very narrow width, full height */
  scaleFrom: number;
  /* subtle parallax offsets in px */
  yFrom: number;
  yTo: number;
  /* heavier scrub on the featured row */
  scrub?: number;
};

const FIRST_ROW: Project[] = [
  {
    id: "01",
    slug: "after",
    title: "After",
    category: "Micro Interaction",
    src: "/images/recent-01.jpg",
    ratio: "rp-ratio-4-3",
    scaleFrom: 0.05,
    yFrom: -28,
    yTo: 18,
    scrub: 0.7,
  },
  {
    id: "02",
    slug: "vogue",
    title: "Vogue",
    category: "Brand Identity",
    src: "/images/recent-02.jpg",
    ratio: "rp-ratio-4-3",
    scaleFrom: 0.05,
    yFrom: 20,
    yTo: -36,
    scrub: 0.7,
  },
];

const FEATURED: Project = {
  id: "03",
  slug: "pulse",
  title: "Pulse",
  category: "GSAP Animation",
  src: "/images/recent-04.jpg",
  ratio: "rp-ratio-16-9",
  scaleFrom: 0.04,
  yFrom: 40,
  yTo: -60,
  // slower expansion for the hero of this section
  scrub: 1.2,
};

const SECOND_ROW: Project[] = [
  {
    id: "04",
    slug: "atlas",
    title: "Atlas",
    category: "Micro Interaction",
    src: "/images/recent-03.jpg",
    ratio: "rp-ratio-4-3",
    scaleFrom: 0.05,
    yFrom: -32,
    yTo: 20,
    scrub: 0.7,
  },
  {
    id: "05",
    slug: "nova",
    title: "Nova",
    category: "Social Media Posts",
    src: "/images/recent-02.jpg",
    ratio: "rp-ratio-4-3",
    scaleFrom: 0.05,
    yFrom: 24,
    yTo: -42,
    scrub: 0.7,
  },
];

function openProject(slug: string) {
  window.location.hash = `#/projects/${slug}`;
}

export default function RecentProjects() {
  const sectionRef = useRef<HTMLElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const reduceMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    );

    const context = gsap.context(() => {
      const cards = section.querySelectorAll<HTMLElement>(".rp-card");

      // Reduced motion: show the finished composition immediately.
      if (reduceMotion.matches) {
        cards.forEach((card) => {
          const frame = card.querySelector<HTMLElement>(".rp-frame");
          if (frame) gsap.set(frame, { scaleX: 1, y: 0 });
        });
        return;
      }

      cards.forEach((card) => {
        const frame = card.querySelector<HTMLElement>(".rp-frame");
        if (!frame) return;

        const meta = card.querySelector<HTMLElement>(".rp-caption");
        const ratio = card.getAttribute("data-ratio") ?? "";

        // Tuned values come from the markup — single source of truth.
        const scaleFrom = parseFloat(card.dataset.scaleFrom ?? "0.15");
        const yFrom = parseFloat(card.dataset.yFrom ?? "0");
        const yTo = parseFloat(card.dataset.yTo ?? "0");
        const scrub = parseFloat(card.dataset.scrub ?? "0.8");
        const isFeatured = ratio === "rp-ratio-16-9";

        // Set the compressed starting state immediately so the image
        // appears narrow on first paint — no visible snap or flash.
        gsap.set(frame, { scaleX: scaleFrom, y: yFrom });
        if (meta) gsap.set(meta, { y: yFrom * 0.35, opacity: 0 });

        // Each card has its OWN ScrollTrigger bound to its own element.
        // The animation only starts when this specific card enters the
        // viewport (top crosses 80% of the viewport height) and finishes
        // when the card reaches 30% — so cards animate strictly one by one,
        // never as a group, never before they are visible.
        // Featured gets a slightly wider range for a slower expansion.
        const start = "top 80%";
        const end = isFeatured ? "top 20%" : "top 30%";

        // Horizontal expansion is the primary animation: a very narrow
        // frame opens outward from its own center to full width, while
        // the height (and therefore the aspect ratio) never changes.
        gsap.to(frame, {
          scaleX: 1,
          y: yTo, // secondary, subtle parallax
          ease: "none",
          scrollTrigger: {
            trigger: card,
            start,
            end,
            scrub,
            invalidateOnRefresh: true,
            // Created from a child component, so refresh after the
            // pinned sections above it have measured their spacing.
            refreshPriority: 1,
          },
        });

        // The caption drifts very slightly so it never feels pinned-fast.
        if (meta) {
          gsap.to(meta, {
            y: yTo * 0.35,
            opacity: 1,
            ease: "none",
            scrollTrigger: {
              trigger: card,
              start: "top 85%",
              end: isFeatured ? "top 35%" : "top 45%",
              scrub,
              invalidateOnRefresh: true,
              refreshPriority: 1,
            },
          });
        }
      });
    }, section);

    return () => context.revert();
  }, []);

  const renderCard = (project: Project) => (
    <article
      className="rp-card rp-card-link"
      data-ratio={project.ratio}
      data-scale-from={project.scaleFrom}
      data-y-from={project.yFrom}
      data-y-to={project.yTo}
      data-scrub={project.scrub ?? 0.8}
      data-slug={project.slug}
      onClick={() => openProject(project.slug)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          openProject(project.slug);
        }
      }}
      tabIndex={0}
      role="link"
      aria-label={`Open ${project.title} case study`}
    >
      <div className={`rp-frame ${project.ratio}`}>
        <img src={project.src} alt={project.title} loading="lazy" />
        <span className="rp-open" aria-hidden="true">
          Open case study →
        </span>
      </div>

      <div className="rp-caption">
        <span className="rp-title">{project.title}</span>
        <span className="rp-meta">{project.category}</span>
      </div>
    </article>
  );

  return (
    <section
      ref={sectionRef}
      id="recent-projects"
      className="recent-projects"
      aria-label="Recent Projects"
    >
      {/* Header */}
      <header className="rp-header">
        <h2>
          We let the <span className="rp-script">Projects</span>
          <br />
          speak for itself.
        </h2>
      </header>

      {/* First row — two side-by-side cards */}
      <div className="rp-row">
        {FIRST_ROW.map((project) => (
          <div key={project.id}>{renderCard(project)}</div>
        ))}
      </div>

      {/* Featured full-width row */}
      <div className="rp-row rp-row-featured">{renderCard(FEATURED)}</div>

      {/* Second row — two side-by-side cards */}
      <div className="rp-row">
        {SECOND_ROW.map((project) => (
          <div key={project.id}>{renderCard(project)}</div>
        ))}
      </div>
    </section>
  );
}
